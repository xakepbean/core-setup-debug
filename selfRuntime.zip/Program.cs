﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace selfRuntime
{
    class Program
    {

        static void Main(string[] args)
        {
            var depsPath = @"D:\selfRuntime\bin\Debug\netcoreapp2.1\console";
            if (args.Length > 0)
                depsPath = args[0];
            if (!Directory.Exists(depsPath))
            {
                Console.WriteLine("请输入文件夹地址");
                return;
            }
            var apphost = Directory.GetFiles(depsPath, "*.exe");
            if (apphost.Length == 0)
            {
                Console.WriteLine("未找到exe文件");
                return;
            }
            string appName = string.Empty;
            string depsFileName = string.Empty;
            foreach (var item in apphost)
            {
                var itemName = Path.GetFileNameWithoutExtension(item);
                var depsfile = Path.Combine(depsPath, $"{itemName}.deps.json");
                if (File.Exists(depsfile))
                {
                    depsFileName = depsfile;
                    appName = itemName;
                    break;
                }
            }

            if (string.IsNullOrWhiteSpace(depsFileName))
            {
                Console.WriteLine("未找到deps.json文件");
                return;
            }

            string runtimeConfigFile = Path.Combine(depsPath, $"{appName}.runtimeconfig.json");
            if (!UpdateRuntimeConfig(runtimeConfigFile))
                return;

            var DepsDlls=GetDepsDll(depsFileName);
            foreach(var item in DepsDlls){
                var vfname=Path.GetFileName(item);
                if(vfname.Equals("hostfxr.dll") || vfname.Equals("hostpolicy.dll") || vfname.Equals($"{appName}.dll"))
                    continue;
                var sourceName=Path.Combine(depsPath,vfname);
                if(File.Exists(sourceName)){
                    var destFileName=Path.Combine(depsPath,"runtime",item);
                    var destDir=Path.GetDirectoryName(destFileName);
                    if(!Directory.Exists(destDir))
                        Directory.CreateDirectory(destDir);
                    File.Move(sourceName,destFileName);
                }
                //Console.WriteLine(item);
            }


            Console.WriteLine("完成");
        }

        static List<string> GetDepsDll(string depsFileName)
        {List<string> depsDlls=new List<string>();
            using (StreamReader depsReader = File.OpenText(depsFileName))
            using (JsonTextReader jsonReader = new JsonTextReader(depsReader))
            {
                JObject depsJson = JObject.Load(jsonReader);
                RecursionJson(depsJson,ref depsDlls);
            }
            return depsDlls;
        }

        static void RecursionJson(JToken token, ref List<string> depsDlls)
        {
            switch (token.Type)
            {
                case JTokenType.Array:
                    var jArray = (JArray)token;
                    //Console.WriteLine("[");
                    foreach (var item in jArray)
                    {
                        RecursionJson(item, ref depsDlls);
                    }
                    //Console.WriteLine("]");
                    break;
                case JTokenType.Object:
                    //Console.WriteLine("{");
                    foreach (var item in ((JObject)token).Properties())
                    {
                        RecursionJson(item, ref depsDlls);
                    }
                    //Console.WriteLine("}");
                    break;
                case JTokenType.Property:
                    var jProperty = (JProperty)token;
                    //Console.Write($"{jProperty.Name}:");
                    if (jProperty.Value.Type == JTokenType.Object && (jProperty.Name == "runtime" || jProperty.Name == "native"))
                    { 
                        string strLib=string.Empty;
                        //Console.WriteLine($"{token.Parent.Parent.Type}"); 
                        if(token.Parent.Parent.Type== JTokenType.Property){
                            //Console.WriteLine($"{"); 
                            strLib=((JProperty)token.Parent.Parent).Name+Path.DirectorySeparatorChar;
                        }
                        //var vParent=token.Parent
                        var jRN = (JObject)jProperty.Value;
                        foreach (var item in jRN.Properties())
                        {
                            //Console.WriteLine(item.Name);
                            depsDlls.Add(strLib+item.Name);
                        }
                    }

                    
                    else
                        RecursionJson(jProperty.Value, ref depsDlls);
                    //Console.WriteLine(",");
                    break;
                default:
                    //Console.Write($"{token}");
                    break;
            }


        }

        static bool UpdateRuntimeConfig(string runtimeConfigFile)
        {
            string RunDirName = ".\\runtimes\\";
            if (!File.Exists(runtimeConfigFile))
            {
                var defaultConfig = JsonConvert.SerializeObject(new
                {
                    runtimeOptions = new
                    {
                        additionalProbingPaths = new List<string> { RunDirName }
                    }
                });
                File.WriteAllText(runtimeConfigFile, defaultConfig, Encoding.UTF8);
            }
            else
            {
                var strConfig = File.ReadAllText(runtimeConfigFile);
                JObject jconfig = JObject.Parse(strConfig);
                if (!jconfig.ContainsKey("runtimeOptions"))
                {
                    jconfig.Add("runtimeOptions", JObject.Parse(JsonConvert.SerializeObject(new
                    {
                        additionalProbingPaths = new List<string> { RunDirName }
                    })));
                }
                else
                {
                    var vPaths = jconfig["runtimeOptions"]["additionalProbingPaths"];
                    if (vPaths == null)
                    {
                        jconfig["runtimeOptions"] = JObject.Parse(JsonConvert.SerializeObject(new
                        {
                            additionalProbingPaths = new List<string> { RunDirName }
                        }));
                    }
                    else
                    {
                        if (vPaths.Type == JTokenType.Array)
                        {
                            if (vPaths.Where(w => w.Equals(RunDirName)).Count() == 0)
                            {
                                JArray array = new JArray();
                                foreach (var item in vPaths)
                                {
                                    array.Add(item.ToString());
                                }
                                array.Add(RunDirName);
                                jconfig["runtimeOptions"]["additionalProbingPaths"] = array;
                            }
                        }
                        else
                        {
                            Console.WriteLine("runtimeconfig.json文件的additionalProbingPaths格式不对");
                            return false;
                        }
                    }
                }
                File.WriteAllText(runtimeConfigFile, jconfig.ToString(), Encoding.UTF8);
            }
            return true;
        }
    }
}
